// Edit daftar produk di bawah ini sesuai list harga kamu.
// Contoh format item: { code: 'A1', name: 'Diamond ML 86', price: 26950, desc: 'Instant proses' }
const PRODUCTS = [
  { code: 'A1', name: 'Produk A', price: 26950, desc: 'Contoh item — ganti dengan data kamu' },
  { code: 'B1', name: 'Produk B', price: 36950, desc: 'Contoh item — ganti dengan data kamu' },
  { code: 'C1', name: 'Produk C', price: 45000, desc: 'Contoh item — ganti dengan data kamu' }
];
